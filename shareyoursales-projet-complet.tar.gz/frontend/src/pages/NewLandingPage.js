import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Menu, X, Clock, DollarSign, Users, Link as LinkIcon, 
  Share2, ThumbsUp, Play, Globe, ChevronRight, Lightbulb,
  Settings, TrendingUp, Award, ArrowUp
} from 'lucide-react';

const NewLandingPage = () => {
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { label: "Comment ça marche ?", href: "#how-it-works" },
    { label: "Mon espace", href: "/login" },
    { label: "Marketplace", href: "#marketplace" },
    { label: "IA Marketing & Ventes", href: "#ai-marketing" },
    { label: "Tarifs", href: "#pricing" },
    { label: "Blog", href: "#blog" },
    { label: "FAQ", href: "#faq" },
    { label: "Partenaires", href: "#partners" },
    { label: "Contact", href: "#contact" }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Bar */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center cursor-pointer" onClick={() => navigate('/')}>
              <div className="flex flex-col items-start">
                <div className="flex items-center space-x-2">
                  <Globe className="w-8 h-8 text-blue-600" />
                  <span className="text-xl font-bold text-blue-700">SHARE YOUR SALES</span>
                </div>
                <span className="text-xs font-semibold text-green-600 ml-10">SHARING IS WINNING - CHA-CHING!</span>
              </div>
            </div>

            {/* Desktop Menu */}
            <div className="hidden lg:flex items-center space-x-6">
              {menuItems.map((item, index) => (
                <a 
                  key={index}
                  href={item.href}
                  onClick={(e) => {
                    if (item.href.startsWith('/')) {
                      e.preventDefault();
                      navigate(item.href);
                    }
                  }}
                  className="text-sm text-gray-700 hover:text-blue-600 transition-colors"
                >
                  {item.label}
                </a>
              ))}
              <button 
                onClick={() => navigate('/login')}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-semibold"
              >
                Se connecter
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 bg-white">
            <div className="px-4 py-4 space-y-4">
              {menuItems.map((item, index) => (
                <a 
                  key={index}
                  href={item.href}
                  onClick={(e) => {
                    if (item.href.startsWith('/')) {
                      e.preventDefault();
                      navigate(item.href);
                    }
                    setMobileMenuOpen(false);
                  }}
                  className="block text-gray-700 hover:text-blue-600"
                >
                  {item.label}
                </a>
              ))}
              <button 
                onClick={() => navigate('/login')}
                className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Se connecter
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section - Purple Background with Animation Description */}
      <section className="pt-32 pb-16 px-4 bg-gradient-to-br from-purple-400 via-purple-500 to-indigo-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h1 className="text-3xl md:text-4xl font-bold mb-6 leading-tight">
            Une animation montrant comment un commercial ou un influenceur<br />
            partage un lien, suit les clics et reçoit des commissions
          </h1>
          <button className="inline-flex items-center px-8 py-4 bg-indigo-900 hover:bg-indigo-800 text-white rounded-lg text-lg font-semibold transition-all shadow-lg">
            <Play className="w-6 h-6 mr-2" />
            Découvrez comment ça fonctionne
          </button>
        </div>
      </section>

      {/* Main Value Proposition */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-8">
            Vendre en ligne n'a jamais été aussi facile.<br />
            Partagez et gagnez !
          </h2>
          
          {/* Three Key Benefits with Illustrations */}
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            {/* Benefit 1: Real-time tracking */}
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-100 to-teal-100 rounded-3xl p-8 h-64 flex items-center justify-center overflow-hidden">
                <Clock className="w-32 h-32 text-blue-600 opacity-20 absolute" />
                <div className="relative z-10">
                  <Clock className="w-20 h-20 text-blue-600 mx-auto mb-4" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mt-6 mb-2">Suivi en temps réel</h3>
            </div>

            {/* Benefit 2: Transparent Commissions */}
            <div className="relative">
              <div className="bg-gradient-to-br from-green-100 to-emerald-100 rounded-3xl p-8 h-64 flex items-center justify-center overflow-hidden">
                <DollarSign className="w-32 h-32 text-green-600 opacity-20 absolute" />
                <div className="relative z-10">
                  <DollarSign className="w-20 h-20 text-green-600 mx-auto mb-4" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mt-6 mb-2">Commissions transparentes</h3>
            </div>

            {/* Benefit 3: Flexible Partnerships */}
            <div className="relative">
              <div className="bg-gradient-to-br from-purple-100 to-pink-100 rounded-3xl p-8 h-64 flex items-center justify-center overflow-hidden">
                <Users className="w-32 h-32 text-purple-600 opacity-20 absolute" />
                <div className="relative z-10">
                  <ThumbsUp className="w-20 h-20 text-purple-600 mx-auto mb-4" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mt-6 mb-2">Partenariats flexibles</h3>
            </div>
          </div>
        </div>
      </section>

      {/* Detailed Description Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="max-w-5xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-6 text-center">
              ShareYourSales.com - Révolutionnez votre commerce en ligne
            </h2>
            
            <div className="prose prose-lg max-w-none text-gray-700 space-y-6">
              <p className="text-lg leading-relaxed">
                La plateforme <strong>ShareYourSales.com</strong> révolutionne le commerce en ligne en proposant une solution SaaS innovante qui connecte commerçants, commerciaux et influenceurs dans un écosystème sécurisé, transparent et rentable.
              </p>

              <h3 className="text-2xl font-bold text-blue-800 mt-8 mb-4">Fonctionnement général</h3>
              <p className="leading-relaxed">
                Le système repose sur un concept simple : la génération et le partage de liens codés et sécurisés permettant de suivre précisément les visites et les transactions effectuées sur le site web d'un commerçant. Ce processus encourage une rémunération équitable et motivante pour toutes les parties prenantes, en temps réel.
              </p>

              <h3 className="text-2xl font-bold text-blue-800 mt-8 mb-4">Deux volets principaux sur la plateforme</h3>
              
              <div className="bg-blue-50 rounded-xl p-6 my-6">
                <h4 className="text-xl font-bold text-blue-900 mb-3">1. Espace Commerçant</h4>
                <p className="mb-4">Cet espace est dédié aux entreprises ou professionnels qui souhaitent :</p>
                <ul className="space-y-2 ml-6">
                  <li className="flex items-start">
                    <ChevronRight className="w-5 h-5 text-blue-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Générer des liens personnalisés pour des produits ou des pages spécifiques de leur site web</span>
                  </li>
                  <li className="flex items-start">
                    <ChevronRight className="w-5 h-5 text-blue-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Suivre les performances commerciales des liens en termes de visites et de conversions</span>
                  </li>
                  <li className="flex items-start">
                    <ChevronRight className="w-5 h-5 text-blue-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Avoir une vue complète sur les commissions versées aux commerciaux et influenceurs en temps réel</span>
                  </li>
                  <li className="flex items-start">
                    <ChevronRight className="w-5 h-5 text-blue-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Accéder à des outils de reporting avancés pour analyser et optimiser leurs stratégies de vente</span>
                  </li>
                </ul>
              </div>

              <div className="bg-green-50 rounded-xl p-6 my-6">
                <h4 className="text-xl font-bold text-green-900 mb-3">2. Espace Commercial / Influenceur</h4>
                <p className="mb-4">Conçu pour les commerciaux et influenceurs, cet espace leur permet de :</p>
                <ul className="space-y-2 ml-6">
                  <li className="flex items-start">
                    <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Recevoir des liens codés directement liés à leurs efforts de promotion</span>
                  </li>
                  <li className="flex items-start">
                    <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Suivre leurs performances en direct avec des indicateurs clairs</span>
                  </li>
                  <li className="flex items-start">
                    <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Recevoir des paiements instantanés directement sur leur compte après chaque transaction</span>
                  </li>
                  <li className="flex items-start">
                    <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Accéder à des outils pour optimiser leur stratégie et augmenter leurs revenus</span>
                  </li>
                </ul>
              </div>

              <h3 className="text-2xl font-bold text-blue-800 mt-8 mb-4">Système de commissions et motivation</h3>
              <p className="leading-relaxed">La plateforme garantit un système transparent et équitable où :</p>
              <ul className="space-y-2 ml-6 my-4">
                <li className="flex items-start">
                  <DollarSign className="w-5 h-5 text-green-600 mr-2 mt-1 flex-shrink-0" />
                  <span>Chaque vente génère automatiquement une commission prédéfinie</span>
                </li>
                <li className="flex items-start">
                  <DollarSign className="w-5 h-5 text-green-600 mr-2 mt-1 flex-shrink-0" />
                  <span>Les montants sont affichés en temps réel, favorisant une motivation immédiate</span>
                </li>
                <li className="flex items-start">
                  <DollarSign className="w-5 h-5 text-green-600 mr-2 mt-1 flex-shrink-0" />
                  <span>Les paiements sont transférés via des options sécurisées (virement, carte bancaire, PayPal ou cryptomonnaie)</span>
                </li>
              </ul>

              <div className="bg-purple-50 rounded-xl p-6 my-6">
                <h3 className="text-2xl font-bold text-purple-900 mb-4">Évolution future : l'onglet Influenceur Sectoriel</h3>
                <p className="leading-relaxed">Un volet supplémentaire sera dédié aux influenceurs, offrant :</p>
                <ul className="space-y-2 ml-6 mt-4">
                  <li className="flex items-start">
                    <Award className="w-5 h-5 text-purple-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Un système de classement et de notation basé sur des avis clients vérifiés</span>
                  </li>
                  <li className="flex items-start">
                    <Award className="w-5 h-5 text-purple-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Une interface permettant aux commerçants de collaborer facilement avec les influenceurs les plus pertinents</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Simple comme partager Section */}
      <section id="how-it-works" className="py-20 px-4 bg-gradient-to-br from-indigo-600 via-purple-600 to-blue-600">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-white text-center mb-16">
            SIMPLE COMME PARTAGER!
          </h2>

          <div className="grid md:grid-cols-3 gap-12">
            {/* Step 1 */}
            <div className="relative">
              <div className="bg-gradient-to-br from-green-400 to-teal-500 rounded-full w-32 h-32 flex items-center justify-center mx-auto mb-6 shadow-2xl">
                <span className="text-5xl font-bold text-white">01</span>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-center">
                <LinkIcon className="w-12 h-12 text-white mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-white mb-3">GÉNÉREZ UN LIEN PERSONNALISÉ</h3>
                <p className="text-white/90">Un lien qui vous est propre, automatiquement généré.</p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full w-32 h-32 flex items-center justify-center mx-auto mb-6 shadow-2xl">
                <span className="text-5xl font-bold text-white">02</span>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-center">
                <Share2 className="w-12 h-12 text-white mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-white mb-3">PARTAGEZ-LE AVEC VOS PROSPECTS OU ABONNÉS</h3>
                <p className="text-white/90">Vos contacts cliquent, vous gagnez. Simple comme ça !</p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full w-32 h-32 flex items-center justify-center mx-auto mb-6 shadow-2xl">
                <span className="text-5xl font-bold text-white">03</span>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-center">
                <ThumbsUp className="w-12 h-12 text-white mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-white mb-3">SUIVEZ LES VENTES ET ENCAISSEZ VOS COMMISSIONS</h3>
                <p className="text-white/90">Recevez des paiements instantanés et voyez combien vous avez gagné grâce à chaque clic.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Tarifs Simples et Transparents</h2>
            <p className="text-xl text-gray-600">Choisissez le plan qui correspond à vos besoins</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Starter Plan */}
            <div className="bg-white rounded-2xl shadow-xl p-8 border-2 border-gray-200 hover:border-blue-500 transition-all">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Starter</h3>
              <div className="mb-6">
                <span className="text-5xl font-bold text-blue-600">490 Dh</span>
                <span className="text-gray-600 ml-2">/ mois</span>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>Jusqu'à 100 affiliés</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>Suivi en temps réel</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>Rapports basiques</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>Support email</span>
                </li>
              </ul>
              <button 
                onClick={() => navigate('/login')}
                className="w-full py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Commencer
              </button>
            </div>

            {/* Professional Plan - Popular */}
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl shadow-2xl p-8 text-white relative transform scale-105">
              <div className="absolute top-0 right-0 bg-yellow-400 text-gray-900 px-4 py-1 rounded-bl-lg rounded-tr-lg font-bold text-sm">
                POPULAIRE
              </div>
              <h3 className="text-2xl font-bold mb-4">Professional</h3>
              <div className="mb-6">
                <span className="text-5xl font-bold">1,490 Dh</span>
                <span className="text-blue-100 ml-2">/ mois</span>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-300 mr-2 mt-1" />
                  <span>Affiliés illimités</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-300 mr-2 mt-1" />
                  <span>MLM jusqu'à 10 niveaux</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-300 mr-2 mt-1" />
                  <span>White Label complet</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-300 mr-2 mt-1" />
                  <span>Support prioritaire</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-300 mr-2 mt-1" />
                  <span>Détection de fraude</span>
                </li>
              </ul>
              <button 
                onClick={() => navigate('/login')}
                className="w-full py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Commencer
              </button>
            </div>

            {/* Enterprise Plan */}
            <div className="bg-white rounded-2xl shadow-xl p-8 border-2 border-gray-200 hover:border-purple-500 transition-all">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Enterprise</h3>
              <div className="mb-6">
                <span className="text-5xl font-bold text-purple-600">Sur devis</span>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>Tout Professional +</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>Serveur dédié</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>Onboarding personnalisé</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>Support 24/7</span>
                </li>
                <li className="flex items-start">
                  <ChevronRight className="w-5 h-5 text-green-600 mr-2 mt-1" />
                  <span>SLA garanti</span>
                </li>
              </ul>
              <button 
                onClick={() => navigate('/login')}
                className="w-full py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition-colors"
              >
                Nous contacter
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Prêt à transformer vos ventes ?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Rejoignez des milliers d'entreprises qui ont déjà boosté leurs revenus avec ShareYourSales
          </p>
          <button 
            onClick={() => navigate('/login')}
            className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all shadow-lg"
          >
            Commencer gratuitement
            <ArrowUp className="w-6 h-6 ml-2 transform rotate-45" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">ShareYourSales</h3>
              <p className="text-gray-400 text-sm">
                La plateforme de gestion d'affiliation qui révolutionne le commerce en ligne.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Produit</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#features" className="hover:text-white">Fonctionnalités</a></li>
                <li><a href="#pricing" className="hover:text-white">Tarifs</a></li>
                <li><a href="#" className="hover:text-white">Intégrations</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Entreprise</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">À propos</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Carrières</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">Centre d'aide</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
                <li><a href="#" className="hover:text-white">Documentation</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2025 ShareYourSales. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default NewLandingPage;
